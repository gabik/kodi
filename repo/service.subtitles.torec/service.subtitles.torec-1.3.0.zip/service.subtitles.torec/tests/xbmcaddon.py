class Addon(object):
	def getAddonInfo(self, type):
		pass
